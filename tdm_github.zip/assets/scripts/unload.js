window.onbeforeunload = function () {
    alert('Please remain on this page until you are finished upgrading.');
    return 'Please remain on this page until you are finished upgrading.';
};