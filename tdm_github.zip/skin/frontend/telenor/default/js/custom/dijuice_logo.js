$jq(document).ready(function(){
 $jq('body').addClass('djuice');	
 $jq('.djuice_logo').show();
 $jq('.telenor_logo').hide();
 });			