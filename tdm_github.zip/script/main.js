$(document).ready(function() {
    $('.lp-div').liMarquee({
        direction: 'left',
        loop: -1,
        scrolldelay: 0,
        scrollamount: 120,
        circular: true,
        drag: true
    });
});