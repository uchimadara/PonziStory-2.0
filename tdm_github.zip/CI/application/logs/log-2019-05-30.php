<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-05-30 01:42:03 --> Severity: Notice  --> Only variable references should be returned by reference /home/kefasb31/public_html/CI/system/core/Common.php 257
DEBUG - 2019-05-30 01:42:03 --> Config Class Initialized
DEBUG - 2019-05-30 01:42:03 --> Hooks Class Initialized
DEBUG - 2019-05-30 01:42:03 --> Utf8 Class Initialized
DEBUG - 2019-05-30 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2019-05-30 01:42:03 --> URI Class Initialized
DEBUG - 2019-05-30 01:42:03 --> Router Class Initialized
ERROR - 2019-05-30 01:42:03 --> 404 Page Not Found --> .env
