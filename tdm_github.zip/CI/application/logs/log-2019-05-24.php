<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-05-24 20:26:06 --> Severity: Notice  --> Only variable references should be returned by reference /home/kefasb31/public_html/CI/system/core/Common.php 257
DEBUG - 2019-05-24 20:26:06 --> Config Class Initialized
DEBUG - 2019-05-24 20:26:06 --> Hooks Class Initialized
DEBUG - 2019-05-24 20:26:06 --> Utf8 Class Initialized
DEBUG - 2019-05-24 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2019-05-24 20:26:06 --> URI Class Initialized
DEBUG - 2019-05-24 20:26:06 --> Router Class Initialized
ERROR - 2019-05-24 20:26:06 --> 404 Page Not Found --> .env
