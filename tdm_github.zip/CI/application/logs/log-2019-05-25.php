<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2019-05-25 10:22:57 --> Severity: Notice  --> Only variable references should be returned by reference /home/kefasb31/public_html/CI/system/core/Common.php 257
DEBUG - 2019-05-25 10:22:57 --> Config Class Initialized
DEBUG - 2019-05-25 10:22:57 --> Hooks Class Initialized
DEBUG - 2019-05-25 10:22:57 --> Utf8 Class Initialized
DEBUG - 2019-05-25 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2019-05-25 10:22:57 --> URI Class Initialized
DEBUG - 2019-05-25 10:22:57 --> Router Class Initialized
ERROR - 2019-05-25 10:22:57 --> 404 Page Not Found --> .env
