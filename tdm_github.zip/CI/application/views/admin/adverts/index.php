<div class="styleshow">
    <a href="<?=site_url('adminpanel/adverts')?>">Summary</a> 
</div>
<h2>Campaigns</h2>
<div class="pageable">
    <?=$campaigns?>
</div>