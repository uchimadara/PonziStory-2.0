<?=$methodsMenu?>

<div class="pageable">
    <?=$balanceUserTable?>
</div>
