<?=$methodsMenu?>
<div>
    <a href="<?=$codeUrl . '/pending'?>">Pending</a> | <a href="<?=$codeUrl . '/ok'?>">Completed</a> | <a href="<?=$codeUrl . '/rejected'?>">Rejected</a> | <a href="<?=$codeUrl . '/cancelled'?>">Cancelled</a>
</div>
<div class="pageable">
<?=$deposits?>
</div>
