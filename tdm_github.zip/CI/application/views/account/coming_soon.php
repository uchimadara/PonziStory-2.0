<h1 class="yellow">Account Upgrade</h1>
<div class="col-lg-8">
    <div class="tile p-10 fs15">
        If you need to upgrade your account we offer credit for any time left on your
        current membership as long as you have more than 7 days left.
        <br/><br/>
        We always try to think about our members therefore we developed a quite unique
        feature in case you ever face following issue. In case you do, You will receive a
        discount on your upgrade based on how many days you have left on your current membership.
        <br/><br/>
        An example might be more useful. Imagine if you had a novice membership with 20 days left,
        that is equal to 2/3 of $5. So, in case you upgraded to Expert, you would have to in reality pay
        $20-$3.33=$16.67 for 20 days of Expert membership.
        <br/><br/>
        Also note that your membership has to have more than 7 days left to get the credits back, as
        you are granted with 7 day free membership upon registration. If you are going to upgrade it
        is best to do so before the last week of your current membership.
    </div>
</div>
