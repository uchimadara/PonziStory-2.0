<h1>Donations Pending Approval</h1>

    <div class="alert alert-danger">Upgrade disabled until all pending donations are approved or rejected.</div>

<a href="<?=SITE_ADDRESS?>back_office/approve_payments">View Pending Donations</a>

