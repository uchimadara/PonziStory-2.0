<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['gaAccount'] = null;
$config['debug']     = false;