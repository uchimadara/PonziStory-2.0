<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['gaAccount'] = 'UA-54962255-1';
$config['debug']     = false;